/* 
	Naufal Prima Yoriko
	13518146
*/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include "stackt.h"
#include "mesintoken.h"

int expon(int a, int b){
	int c = a;
	if (b==0) return 1;
	b--;
	while(b){
		a*=c;
		b--;
	}
	return a;
}

int operate(int a, int b, char r){
	if(r=='+') return a + b;
	else if (r=='^') return (int) expon(a,b);
	else if (r=='-') return a - b;
	else if (r=='*') return a * b;
	else if (r=='/') return a / b;
}

int main(){
    Stack S;
    int a,b,c;
    CreateEmpty(&S);
    
    STARTTOKEN();
    if(EndToken) printf("Ekspresi kosong\n");
    while(!EndToken){
		if(CToken.tkn == 'b'){
			printf("%d\n", CToken.val);
			Push(&S, CToken.val);
		}
		else{
			Pop(&S, &a);
			Pop(&S, &b);
			//printf("%d %d\n", a,b);
			c = operate(b,a,CToken.tkn);
			printf("%d %c %d\n%d\n", b, CToken.tkn, a, c);
			Push(&S, c);
			
		}
		ADVTOKEN();
		if(EndToken) {
			if(IsEmpty(S)) printf("Ekspresi kosong\n");
			else{
				Pop(&S, &a);
				printf("Hasil=%d\n", a);
			}
		}
	}
    return 0;
}
